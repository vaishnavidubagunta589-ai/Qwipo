import { ProductCard } from "./ProductCard";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";
import electronicsImg from "@/assets/electronics-products.jpg";
import medicalImg from "@/assets/medical-supplies.jpg";
import groceryImg from "@/assets/grocery-products.jpg";

const recommendedProducts = [
  {
    id: "1",
    name: "Samsung Galaxy A54 5G Smartphone",
    category: "Electronics",
    price: 38999,
    originalPrice: 42999,
    rating: 4.3,
    reviewCount: 245,
    image: electronicsImg,
    inStock: true,
    isRecommended: true,
    discount: 9
  },
  {
    id: "2",
    name: "Digital Blood Pressure Monitor",
    category: "Medical Supplies",
    price: 2499,
    originalPrice: 3299,
    rating: 4.5,
    reviewCount: 189,
    image: medicalImg,
    inStock: true,
    isRecommended: true,
    discount: 24
  },
  {
    id: "3",
    name: "Organic Rice & Pulses Combo Pack",
    category: "Grocery & FMCG",
    price: 1299,
    originalPrice: 1599,
    rating: 4.2,
    reviewCount: 312,
    image: groceryImg,
    inStock: true,
    isRecommended: true,
    discount: 19
  },
  {
    id: "4",
    name: "Wireless Bluetooth Earbuds Pro",
    category: "Electronics",
    price: 4999,
    originalPrice: 7999,
    rating: 4.4,
    reviewCount: 156,
    image: electronicsImg,
    inStock: true,
    isRecommended: true,
    discount: 38
  }
];

export function RecommendationsSection() {
  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground">Recommended for You</h2>
            <p className="text-muted-foreground">AI-powered suggestions based on your business profile</p>
          </div>
        </div>
        <Button variant="outline" className="text-primary border-primary hover:bg-primary-light">
          View All <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {recommendedProducts.map((product) => (
          <ProductCard key={product.id} {...product} />
        ))}
      </div>
    </section>
  );
}