import { Star, ShoppingCart, Heart, Package } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface ProductCardProps {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  inStock: boolean;
  isRecommended?: boolean;
  discount?: number;
}

export function ProductCard({
  id,
  name,
  category,
  price,
  originalPrice,
  rating,
  reviewCount,
  image,
  inStock,
  isRecommended = false,
  discount
}: ProductCardProps) {
  return (
    <Card className="group hover:shadow-lg transition-all duration-300 border-border/50 hover:border-primary/20">
      <CardContent className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <img
            src={image}
            alt={name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          
          {isRecommended && (
            <Badge className="absolute top-3 left-3 bg-gradient-primary text-white border-0">
              <Star className="w-3 h-3 mr-1 fill-current" />
              Recommended
            </Badge>
          )}
          
          {discount && (
            <Badge className="absolute top-3 right-3 bg-gradient-accent text-white border-0">
              {discount}% OFF
            </Badge>
          )}

          <Button
            size="sm"
            variant="secondary"
            className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 hover:bg-white shadow-md"
          >
            <Heart className="w-4 h-4" />
          </Button>
        </div>

        <div className="p-4">
          <div className="flex items-center justify-between mb-2">
            <Badge variant="secondary" className="text-xs">
              {category}
            </Badge>
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 fill-warning text-warning" />
              <span className="text-sm font-medium">{rating}</span>
              <span className="text-xs text-muted-foreground">({reviewCount})</span>
            </div>
          </div>

          <h3 className="font-semibold text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {name}
          </h3>

          <div className="flex items-center gap-2 mb-3">
            <span className="text-lg font-bold text-foreground">₹{price.toLocaleString()}</span>
            {originalPrice && (
              <span className="text-sm text-muted-foreground line-through">
                ₹{originalPrice.toLocaleString()}
              </span>
            )}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1 text-sm">
              <Package className="w-4 h-4" />
              <span className={inStock ? "text-success" : "text-destructive"}>
                {inStock ? "In Stock" : "Out of Stock"}
              </span>
            </div>

            <Button 
              size="sm" 
              variant="gradient"
              disabled={!inStock}
            >
              <ShoppingCart className="w-4 h-4 mr-1" />
              Add to Cart
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}