import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, Package, ShoppingCart, Star } from "lucide-react";

const stats = [
  {
    title: "Total Orders",
    value: "248",
    change: "+12%",
    trend: "up",
    icon: ShoppingCart,
    bgColor: "bg-primary/10",
    iconColor: "text-primary"
  },
  {
    title: "Products Purchased",
    value: "1,247",
    change: "+8%",
    trend: "up",
    icon: Package,
    bgColor: "bg-success/10",
    iconColor: "text-success"
  },
  {
    title: "Monthly Savings",
    value: "₹32,450",
    change: "+23%",
    trend: "up",
    icon: TrendingUp,
    bgColor: "bg-warning/10",
    iconColor: "text-warning"
  },
  {
    title: "Supplier Rating",
    value: "4.8",
    change: "+0.2",
    trend: "up",
    icon: Star,
    bgColor: "bg-primary/10",
    iconColor: "text-primary"
  }
];

export function StatsCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <Card key={index} className="border-border/50 hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </p>
                <p className="text-2xl font-bold text-foreground mt-1">
                  {stat.value}
                </p>
                <p className="text-sm text-success flex items-center gap-1 mt-2">
                  <TrendingUp className="w-3 h-3" />
                  {stat.change} from last month
                </p>
              </div>
              <div className={`w-12 h-12 rounded-lg ${stat.bgColor} flex items-center justify-center`}>
                <stat.icon className={`w-6 h-6 ${stat.iconColor}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}