import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  User, 
  Store, 
  MapPin, 
  Phone, 
  Mail, 
  Edit2,
  Shield,
  Bell,
  CreditCard,
  Truck,
  Settings
} from "lucide-react";

const businessDetails = {
  storeName: "Ravi General Store",
  ownerName: "Ravi Kumar",
  storeType: "Kirana Store",
  location: "MG Road, Bangalore",
  phone: "+91 98765 43210",
  email: "ravi.store@gmail.com",
  gstNumber: "29ABCDE1234F1Z5",
  establishedYear: "2018"
};

const preferences = [
  { category: "Electronics", interest: "High", orders: 45 },
  { category: "Medical Supplies", interest: "Medium", orders: 23 },
  { category: "Grocery & FMCG", interest: "High", orders: 67 },
  { category: "Home Appliances", interest: "Low", orders: 8 }
];

const recentActivity = [
  { action: "Order Placed", details: "Medical supplies worth ₹12,450", time: "2 hours ago" },
  { action: "Profile Updated", details: "Added new payment method", time: "1 day ago" },
  { action: "Wishlist Updated", details: "Added 3 new products", time: "3 days ago" },
  { action: "Order Delivered", details: "Electronics order ORD-2024-001", time: "5 days ago" }
];

export default function Profile() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      
      <main className="p-6 max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Profile</h1>
          <p className="text-muted-foreground">Manage your business profile and preferences</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Profile Card */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-border/50">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5 text-primary" />
                  Business Information
                </CardTitle>
                <Button variant="outline" size="sm">
                  <Edit2 className="w-4 h-4 mr-2" />
                  Edit
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Store Name</Label>
                    <p className="text-foreground font-semibold mt-1">{businessDetails.storeName}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Owner Name</Label>
                    <p className="text-foreground font-semibold mt-1">{businessDetails.ownerName}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Store Type</Label>
                    <Badge className="mt-1 bg-primary-light text-primary-dark">{businessDetails.storeType}</Badge>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Established</Label>
                    <p className="text-foreground font-semibold mt-1">{businessDetails.establishedYear}</p>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">{businessDetails.location}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">{businessDetails.phone}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">{businessDetails.email}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Shield className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">GST: {businessDetails.gstNumber}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Preferences */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-primary" />
                  Category Preferences
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  AI uses this data to personalize your product recommendations
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {preferences.map((pref, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                      <div>
                        <p className="font-medium text-foreground">{pref.category}</p>
                        <p className="text-sm text-muted-foreground">{pref.orders} orders placed</p>
                      </div>
                      <Badge
                        variant={
                          pref.interest === "High" ? "default" :
                          pref.interest === "Medium" ? "secondary" : "outline"
                        }
                        className={
                          pref.interest === "High" ? "bg-success text-white" :
                          pref.interest === "Medium" ? "bg-warning text-white" : ""
                        }
                      >
                        {pref.interest} Interest
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Bell className="w-4 h-4 mr-2" />
                  Notification Settings
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Payment Methods
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Truck className="w-4 h-4 mr-2" />
                  Delivery Preferences
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Shield className="w-4 h-4 mr-2" />
                  Security Settings
                </Button>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="border-l-2 border-primary/20 pl-4 pb-4 last:pb-0">
                      <p className="font-medium text-foreground text-sm">{activity.action}</p>
                      <p className="text-sm text-muted-foreground mt-1">{activity.details}</p>
                      <p className="text-xs text-muted-foreground mt-2">{activity.time}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}