import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { StatsCards } from "@/components/dashboard/StatsCards";
import { RecommendationsSection } from "@/components/dashboard/RecommendationsSection";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, Package, Clock, ArrowRight } from "lucide-react";
import heroImg from "@/assets/hero-marketplace.jpg";

const recentOrders = [
  {
    id: "ORD-2024-001",
    supplier: "TechCorp Distributors",
    amount: "₹45,299",
    status: "Delivered",
    date: "2 days ago"
  },
  {
    id: "ORD-2024-002",
    supplier: "MediSupply Hub",
    amount: "₹12,450",
    status: "In Transit",
    date: "5 days ago"
  },
  {
    id: "ORD-2024-003",
    supplier: "Fresh Grocery Co.",
    amount: "₹8,999",
    status: "Processing",
    date: "1 week ago"
  }
];

const trendingCategories = [
  { name: "Electronics", growth: "+15%", products: 245 },
  { name: "Medical Supplies", growth: "+28%", products: 89 },
  { name: "Grocery & FMCG", growth: "+12%", products: 156 },
  { name: "Home Appliances", growth: "+8%", products: 78 }
];

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      
      <main className="p-6 space-y-8">
        {/* Welcome Hero Section */}
        <section className="relative overflow-hidden rounded-2xl bg-gradient-subtle border shadow-lg">
          <div className="absolute inset-0">
            <img
              src={heroImg}
              alt="Marketplace Hero"
              className="w-full h-full object-cover opacity-10"
            />
          </div>
          <div className="relative p-8 lg:p-12">
            <div className="max-w-2xl">
              <h1 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
                Welcome back, Ravi! 👋
              </h1>
              <p className="text-lg text-muted-foreground mb-6">
                Discover new products tailored for your business. We've found <strong>24 new recommendations</strong> that match your buying patterns.
              </p>
              <div className="flex gap-4">
                <Button variant="gradient">
                  <Package className="w-4 h-4 mr-2" />
                  Explore Products
                </Button>
                <Button variant="outline" className="border-primary text-primary hover:bg-primary-light">
                  View Analytics
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Overview */}
        <StatsCards />

        {/* AI Recommendations */}
        <RecommendationsSection />

        {/* Recent Activity & Trending */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Orders */}
          <Card className="border-border/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-primary" />
                Recent Orders
              </CardTitle>
              <Button variant="ghost" size="sm" className="text-primary">
                View All <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                    <div>
                      <p className="font-medium text-foreground">{order.id}</p>
                      <p className="text-sm text-muted-foreground">{order.supplier}</p>
                      <p className="text-xs text-muted-foreground">{order.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-foreground">{order.amount}</p>
                      <Badge
                        variant={
                          order.status === "Delivered" ? "default" :
                          order.status === "In Transit" ? "secondary" : "outline"
                        }
                        className={
                          order.status === "Delivered" ? "bg-success text-white" :
                          order.status === "In Transit" ? "bg-warning text-white" : ""
                        }
                      >
                        {order.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Trending Categories */}
          <Card className="border-border/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Trending Categories
              </CardTitle>
              <Button variant="ghost" size="sm" className="text-primary">
                Explore <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {trendingCategories.map((category, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                    <div>
                      <p className="font-medium text-foreground">{category.name}</p>
                      <p className="text-sm text-muted-foreground">{category.products} products</p>
                    </div>
                    <Badge className="bg-gradient-accent text-white border-0">
                      {category.growth}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}