import { useState } from "react";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { ProductCard } from "@/components/dashboard/ProductCard";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Search, Filter, Grid, List, SlidersHorizontal } from "lucide-react";
import electronicsImg from "@/assets/electronics-products.jpg";
import medicalImg from "@/assets/medical-supplies.jpg";
import groceryImg from "@/assets/grocery-products.jpg";

const categories = [
  "All Categories",
  "Electronics",
  "Medical Supplies", 
  "Grocery & FMCG",
  "Home Appliances",
  "Office Supplies"
];

const allProducts = [
  {
    id: "1",
    name: "Samsung Galaxy A54 5G Smartphone",
    category: "Electronics",
    price: 38999,
    originalPrice: 42999,
    rating: 4.3,
    reviewCount: 245,
    image: electronicsImg,
    inStock: true,
    isRecommended: true,
    discount: 9
  },
  {
    id: "2",
    name: "Digital Blood Pressure Monitor",
    category: "Medical Supplies",
    price: 2499,
    originalPrice: 3299,
    rating: 4.5,
    reviewCount: 189,
    image: medicalImg,
    inStock: true,
    isRecommended: false,
    discount: 24
  },
  {
    id: "3",
    name: "Organic Rice & Pulses Combo Pack",
    category: "Grocery & FMCG",
    price: 1299,
    originalPrice: 1599,
    rating: 4.2,
    reviewCount: 312,
    image: groceryImg,
    inStock: true,
    isRecommended: true,
    discount: 19
  },
  {
    id: "4",
    name: "Wireless Bluetooth Earbuds Pro",
    category: "Electronics",
    price: 4999,
    originalPrice: 7999,
    rating: 4.4,
    reviewCount: 156,
    image: electronicsImg,
    inStock: true,
    isRecommended: false,
    discount: 38
  },
  {
    id: "5",
    name: "Pulse Oximeter Digital Display",
    category: "Medical Supplies",
    price: 1899,
    rating: 4.1,
    reviewCount: 203,
    image: medicalImg,
    inStock: false,
    isRecommended: false
  },
  {
    id: "6",
    name: "Premium Basmati Rice 10kg",
    category: "Grocery & FMCG",
    price: 2499,
    originalPrice: 2899,
    rating: 4.6,
    reviewCount: 445,
    image: groceryImg,
    inStock: true,
    isRecommended: true,
    discount: 14
  }
];

export default function Products() {
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const filteredProducts = allProducts.filter(product => {
    const matchesCategory = selectedCategory === "All Categories" || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      
      <main className="p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Products</h1>
          <p className="text-muted-foreground">Discover products tailored for your business needs</p>
        </div>

        {/* Filters & Search */}
        <Card className="mb-6 border-border/50">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
              <div className="flex flex-col sm:flex-row gap-4 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select defaultValue="recommended">
                  <SelectTrigger className="w-full sm:w-[150px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recommended">Recommended</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <SlidersHorizontal className="w-4 h-4" />
                  More Filters
                </Button>
                
                <div className="flex items-center border rounded-lg">
                  <Button
                    variant={viewMode === "grid" ? "secondary" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                    className="rounded-r-none"
                  >
                    <Grid className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "secondary" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                    className="rounded-l-none"
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Summary */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <p className="text-muted-foreground">
              Showing {filteredProducts.length} of {allProducts.length} products
            </p>
            {selectedCategory !== "All Categories" && (
              <Badge variant="secondary" className="text-primary">
                {selectedCategory}
              </Badge>
            )}
          </div>
        </div>

        {/* Products Grid */}
        <div className={viewMode === "grid" 
          ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          : "space-y-4"
        }>
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} {...product} />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <Filter className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-foreground mb-2">No products found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filters</p>
          </div>
        )}
      </main>
    </div>
  );
}